<section>
    <header class="major">
        <h2>Ante interdum</h2>
    </header>
    <div class="mini-posts">
        <article>
            <a href="#" class="image"><img src="<?php echo base_url(); ?>assets/front/images/pic07.jpg" alt="" /></a>
            <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>
        </article>
        <article>
            <a href="#" class="image"><img src="<?php echo base_url(); ?>assets/front/images/pic08.jpg" alt="" /></a>
            <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>
        </article>
        <article>
            <a href="#" class="image"><img src="<?php echo base_url(); ?>assets/front/images/pic09.jpg" alt="" /></a>
            <p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>
        </article>
    </div>
    <ul class="actions">
        <li><a href="#" class="button">More</a></li>
    </ul>
</section>
