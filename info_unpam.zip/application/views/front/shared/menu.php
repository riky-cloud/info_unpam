<nav id="menu">
    <header class="major">
        <h2>Menu</h2>
    </header>
    <ul>
        <li><a href="<?php echo base_url(); ?>">Home</a></li>
        <li><a href="<?php echo base_url(); ?>">info wisuda</a></li>
        <li><a href="<?php echo base_url(); ?>">Nomor dosen</a></li>
        <!-- <li>
            <span class="opener">Another Submenu</span>
            <ul>
                <li><a href="#">Lorem Dolor</a></li>
                <li><a href="#">Ipsum Adipiscing</a></li>
                <li><a href="#">Tempus Magna</a></li>
                <li><a href="#">Feugiat Veroeros</a></li>
            </ul>
        </li> -->
    </ul>
</nav>
